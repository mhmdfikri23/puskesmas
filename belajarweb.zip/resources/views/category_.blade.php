@extends('layouts.main')

@section('container')

<h1 class="mb-5">Blog Category : {{ $category }}</h1>
    @foreach ($posts as $post)
    <article class="mb-5">
        <h2><a href="/posts/{{ $post->slug }}" class="text-decoration-none">{{ $post->tittle  }}</a></h2>
        <h5>By : <a href="/authors/{{ $post->author->username }}" class="text-decoration-none">{{ $post->author->name }}</a> in <a style="text-decoration:none" href="/posts?category={{ $post->category->slug }}"> {{ $post->category->name }}</a> </h5>
        {{ $post->excerpt }}... <a style="text-decoration:none"     href="/posts/{{ $post->slug }}">lanjutkan membaca</a>
    </article>
    
    @endforeach
    <a href="/categories" class="text-decoration-none">Back Page</a>
@endsection
